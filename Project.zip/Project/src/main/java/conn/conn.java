package conn;

import java.sql.*;

public class conn {
    public Connection con;
    public Connection GetDatabseConn()
    {
        try {
            con = DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1:3306/hospitaldb",
                    "root",
                    "Lima@MM2"
            );
            System.out.println("Connected to the database successfully");


        }catch (SQLException e)
        {
            e.printStackTrace();
        }
        return con;
    }
}
