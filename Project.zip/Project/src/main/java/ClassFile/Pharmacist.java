package ClassFile;

import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.services.gmail.Gmail;
import conn.conn;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.swing.*;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static ClassFile.inform.*;

public class Pharmacist {
    private conn con = new conn();
    private String name;
    private String contactNo;
    private String email;
    // Constructor
    public Pharmacist(String name, String contactNo, String email) {
        this.name = name;
        this.contactNo = contactNo;
        this.email = email;
    }

    public Pharmacist()
    {

    }
    public void informPharmacist() throws IOException, MessagingException, GeneralSecurityException {
        final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
        Gmail service = new Gmail.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
                .setApplicationName("Health")
                .build();

        String query = "SELECT PharmacistID, Email FROM pharmacist";
        List<String> emailList = new ArrayList<>();

        try (Connection connection = con.GetDatabseConn();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                int pharmacistID = resultSet.getInt("PharmacistID");
                String email = resultSet.getString("Email");

                // Get all low-stock items for the pharmacist
                List<String> lowStockItems = getLowStockItems(pharmacistID);
                boolean x = false;
                for (int i = 0; i < lowStockItems.size(); i++) {
                    x = this.update_database_about_email(lowStockItems.get(i),pharmacistID);
                }

                if(x)
                {
                    if (!lowStockItems.isEmpty()) {
                        String emailBody = generateEmailBody(lowStockItems);
                        emailList.add(email);


                        MimeMessage emailMessage = createEmail(email, "limuthukottagoda@gmail.com", "Health - Low Stock Alert", emailBody);

                        sendMessage(service, "me", emailMessage);

                    }
                }else {
                    return;
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        System.out.println("Emails Sent: " + emailList.size());
    }

    // Add Pharmacist to Database
    public void addPharmacistToDatabase() {
        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(null, "Invalid email format!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (isEmailInDatabase(email)) {
            JOptionPane.showMessageDialog(null, "Email already exists in the database!", "Duplicate Entry", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection connection = con.GetDatabseConn()) {
            String query = "INSERT INTO pharmacist (Name, ContactNo, Email) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, contactNo);
                preparedStatement.setString(3, email);
                int rowsInserted = preparedStatement.executeUpdate();
                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(null, "Pharmacist added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error inserting pharmacist into the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error connecting to the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean update_database_about_email(String item, int pharmacistID) {
        // Check if the appointment ID exists
        String q1 = "SELECT * FROM emailtopharmacist WHERE pharmacistID = ?";
        String q2 = "INSERT INTO emailtopharmacist ( pharmacistID,item) VALUES (?, ?)";
        System.out.println("ID"+ pharmacistID + ", " + item);
        try (Connection connection = con.GetDatabseConn()) {
            try (PreparedStatement preparedStatement = connection.prepareStatement(q1)) {
                preparedStatement.setInt(1, pharmacistID);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    // If no records found, insert the new entry
                    if (!resultSet.next()) {
                        try (PreparedStatement preparedStatement2 = connection.prepareStatement(q2)) {
                            preparedStatement2.setInt(1, pharmacistID);
                            preparedStatement2.setString(2,item);

                            int rowsInserted = preparedStatement2.executeUpdate();

                            return true;
                        } catch (SQLException e) {
                            JOptionPane.showMessageDialog(null,
                                    "Error inserting data into the database: " + e.getMessage(),
                                    "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null,
                        "Error checking existing records in the database: " + e.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Database connection error: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }

        return false;
    }

    private List<String> getLowStockItems(int pharmacistID) {
        List<String> lowStockItems = new ArrayList<>();
        String query = "SELECT Name FROM inventory WHERE Quantity < 5";

        try (Connection connection = con.GetDatabseConn();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                lowStockItems.add(resultSet.getString("Name"));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching low-stock items: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }

        return lowStockItems;
    }

    // **Helper method to generate email body**
    private String generateEmailBody(List<String> items) {
        StringBuilder body = new StringBuilder("Dear Pharmacist,\n\nThe following items are low in stock:\n\n");

        for (String item : items) {
            body.append("- ").append(item).append("\n");
        }

        body.append("\nPlease restock them as soon as possible.\n\nBest Regards,\nYour Inventory System");
        return body.toString();
    }
    // Check if email exists in the database
    public boolean isEmailInDatabase(String email) {
        try (Connection connection = con.GetDatabseConn()) {
            String query = "SELECT Email FROM pharmacist WHERE Email = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, email);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    return resultSet.next(); // If a record is found, return true
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error checking email in database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    // Validate Email
    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
