package ClassFile;

import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.services.gmail.Gmail;
import conn.conn;

import java.time.ZoneId;
import java.util.Date;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.swing.*;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.sql.*;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.time.LocalDate;
import ClassFile.inform;

import static ClassFile.inform.*;

public class appointment {
    public conn con = new conn();
    private int appointmentID;
    private int patientID;
    private int doctorID;
    private String time;
    private String date;
    private String patientName;
    private String doctorName;
    public inform inform = new inform();

    // Constructor with AppointmentID (for existing appointments)
// Constructor with Names instead of IDs
    public appointment(int appointmentID, String patientName, String doctorName, String time, String date) {
        this.appointmentID = appointmentID;
        this.patientID = 0; // Or set as default
        this.doctorID = 0; // Or set as default
        this.time = time;
        this.date = date;
        this.patientName = patientName; // Add this field
        this.doctorName = doctorName; // Add this field

    }

    public appointment() {

    }

    // Constructor without AppointmentID (for new appointments)
    public appointment(int patientID, int doctorID, String time, String date) {
        this.patientID = patientID;
        this.doctorID = doctorID;
        this.time = time;
        this.date = date;
    }

    public void informPatient()   throws IOException, MessagingException, GeneralSecurityException {
        Date Datex;
        int apId;
        final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
        Gmail service = new Gmail.Builder(HTTP_TRANSPORT, JSON_FACTORY, inform.getCredentials(HTTP_TRANSPORT))
                .setApplicationName("Helth")
                .build();
        ArrayList<Integer> id = new ArrayList<>();
        ArrayList<String> Email = new ArrayList<>();
        String quary1 = "SELECT AppointmentID, Date, Time, PatientID FROM appointment";
        String quary2 = "SELECT Email FROM patient WHERE PatientID = ?";

        try (Connection connection = con.GetDatabseConn()) {
            // Fetch appointments
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(quary1)) {
                while (resultSet.next()) {
                     apId = resultSet.getInt("AppointmentID");
                    int PatientID = resultSet.getInt("PatientID");
                    Time Time = resultSet.getTime("Time");
                     Datex = resultSet.getDate("Date");
                    System.out.println(PatientID + ", " + Time +" , " + Datex );
                    // Check if the date meets the criteria
                    boolean x = this.update_database_about_email(Datex,apId);
                    if(x)
                    {
                        if (this.CheckDate(Datex)) {
                            id.add(PatientID);
                        }
                    }else {
                        return;
                    }
                }
            }
            System.out.println("Pa Size: " +id.size());
            // Fetch and process patient emails
            for (int patientID : id) {
                try (PreparedStatement preparedStatement = connection.prepareStatement(quary2)) {
                    preparedStatement.setInt(1, patientID);
                    try (ResultSet resultSet2 = preparedStatement.executeQuery()) {
                        if (resultSet2.next()) {
                            String email = resultSet2.getString("Email");
                            // You can now send an email or process the email as needed
                            Email.add(email);
                        }
                    }
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching data from the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        System.out.println("Email Size: " +Email.size());
        for (int i = 0; i < Email.size(); i++) {
            MimeMessage email = createEmail(Email.get(i), "limuthukottagoda@gmail.com", "Helth - Apoiment Reminder", "To Day is Your Appointment");
            sendMessage(service, "me", email);
        }
    }


    public boolean update_database_about_email(Date date, int apId) {
        // Check if the appointment ID exists
        String q1 = "SELECT * FROM emailstopatient WHERE appointmentID = ?";
        String q2 = "INSERT INTO emailstopatient (Date, appointmentID) VALUES (?, ?)";

        try (Connection connection = con.GetDatabseConn()) {
            try (PreparedStatement preparedStatement = connection.prepareStatement(q1)) {
                preparedStatement.setInt(1, apId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    // If no records found, insert the new entry
                    if (!resultSet.next()) {
                        try (PreparedStatement preparedStatement2 = connection.prepareStatement(q2)) {
                            preparedStatement2.setDate(1, new java.sql.Date(date.getTime()));
                            preparedStatement2.setInt(2, apId);
                            int rowsInserted = preparedStatement2.executeUpdate();

                            return true;
                        } catch (SQLException e) {
                            JOptionPane.showMessageDialog(null,
                                    "Error inserting data into the database: " + e.getMessage(),
                                    "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null,
                        "Error checking existing records in the database: " + e.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Database connection error: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }

        return false;
    }




    public boolean CheckDate(Date date) {
        // Get the current date
        Date currentDate = new Date(); // This gives the current date and time

        // Compare the dates by comparing their time values (in milliseconds)
        return currentDate.getDate() == date.getDate() && currentDate.getMonth() == date.getMonth() && currentDate.getYear() == date.getYear();
    }


    public List<appointment> getMonthlyAppointments() {
        List<appointment> appointments = new ArrayList<>();

        // Get first day of the month and current date as SQL Date
        LocalDate today = LocalDate.now();
        LocalDate firstDay = today.withDayOfMonth(1);

        try (Connection connection = con.GetDatabseConn();
             PreparedStatement stmt = connection.prepareStatement(
                     "SELECT a.AppointmentID, p.Name AS PatientName, d.Name AS DoctorName, a.Time, a.Date " +
                             "FROM appointment a " +
                             "JOIN patient p ON a.PatientID = p.PatientID " +
                             "JOIN doctor d ON a.DoctorID = d.DoctorID " +
                             "WHERE a.Date BETWEEN ? AND ?")) {

            stmt.setDate(1, java.sql.Date.valueOf(firstDay));
            stmt.setDate(2, java.sql.Date.valueOf(today));

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    appointments.add(new appointment(
                            rs.getInt("AppointmentID"),
                            rs.getString("PatientName"),
                            rs.getString("DoctorName"),
                            rs.getString("Time"),
                            rs.getString("Date")
                    ));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Error fetching monthly appointments: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }

        return appointments;
    }



    // Add new appointment to the database
    public void addAppointmentToDatabase(int doctorID, int patientID) {
        try (Connection connection = con.GetDatabseConn()) {
            String query = "INSERT INTO appointment (PatientID, DoctorID, Time, Date) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, patientID);
                preparedStatement.setInt(2, doctorID);
                preparedStatement.setTime(3, Time.valueOf(LocalTime.now()));
                preparedStatement.setDate(4, new java.sql.Date(System.currentTimeMillis())); // FIXED

                int rowsInserted = preparedStatement.executeUpdate();
                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(null, "Appointment added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error inserting data into the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error connecting to the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    // Get all appointments from the database
    // Get all appointments with doctor and patient names
    public static List<appointment> getAllAppointments() {
        List<appointment> appointments = new ArrayList<>();
        conn con = new conn();
        try (Connection connection = con.GetDatabseConn()) {
            // Use JOIN to fetch doctor and patient names
            String query = "SELECT a.AppointmentID, p.Name AS PatientName, d.Name AS DoctorName, a.Time, a.Date " +
                    "FROM appointment a " +
                    "JOIN patient p ON a.PatientID = p.PatientID " +
                    "JOIN doctor d ON a.DoctorID = d.DoctorID";

            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    int appointmentID = resultSet.getInt("AppointmentID");
                    String patientName = resultSet.getString("PatientName");
                    String doctorName = resultSet.getString("DoctorName");
                    String time = resultSet.getString("Time");
                    String date = resultSet.getString("Date");

                    // Create a new appointment object (you may need a new constructor)
                    appointment app = new appointment(appointmentID, patientName, doctorName, time, date);
                    appointments.add(app);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching appointments from the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return appointments;
    }

    public boolean removeAppointment(int appointmentID) {
        // Query to check if the appointment exists
        String checkQuery = "SELECT * FROM appointment WHERE AppointmentID = ?";
        // Query to delete the appointment
        String deleteQuery = "DELETE FROM appointment WHERE AppointmentID = ?";

        try (Connection connection = con.GetDatabseConn()) {
            // Check if the appointment exists
            try (PreparedStatement checkStatement = connection.prepareStatement(checkQuery)) {
                checkStatement.setInt(1, appointmentID);
                try (ResultSet resultSet = checkStatement.executeQuery()) {
                    if (!resultSet.next()) {
                        // If no records are found, the appointment doesn't exist
                        JOptionPane.showMessageDialog(null, "Appointment not found!", "Error", JOptionPane.ERROR_MESSAGE);
                        return false;
                    }
                }
            }

            // Delete the appointment if it exists
            try (PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {
                deleteStatement.setInt(1, appointmentID);
                int rowsDeleted = deleteStatement.executeUpdate();
                if (rowsDeleted > 0) {
                    JOptionPane.showMessageDialog(null, "Appointment removed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "Error removing appointment. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    // Remove appointment from the database
    public void removeAppointmentFromDatabase(int appointmentID) {
        try (Connection connection = con.GetDatabseConn()) {
            String query = "DELETE FROM appointment WHERE AppointmentID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, appointmentID);
                int rowsDeleted = preparedStatement.executeUpdate();
                if (rowsDeleted > 0) {
                    JOptionPane.showMessageDialog(null, "Appointment removed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error deleting data from the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error connecting to the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }
    // Getter and Setter methods
    public int getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public int getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(int doctorID) {
        this.doctorID = doctorID;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
