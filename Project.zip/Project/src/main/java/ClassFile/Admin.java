package ClassFile;

import conn.conn;

import java.util.ArrayList;
import java.util.List;

public class Admin {
    private conn con = new conn();
    public double PriceOfoneP = 1000.00;
    private inventory inv = new inventory();
    private patient p = new patient();
    private appointment ap = new appointment();

    // Lists to store inventory items and monthly appointments
    public List<inventory.InventoryItem> itemsIninv;
    public List<appointment> apoiments;

    // Constructor to initialize inventory and monthly appointments
    public Admin() {
        this.itemsIninv = inv.getItems() != null ? inv.getItems() : new ArrayList<>();
        this.apoiments = ap.getMonthlyAppointments() != null ? ap.getMonthlyAppointments() : new ArrayList<>();
    }
/*
* if (apoiments.isEmpty()) {
            allData.add("No appointments available this month.");
        } else {
            for (appointment appt : apoiments) {
                allData.add(appt.getPatientName().toString());
            }
        }
* */
    // Method to get all data (inventory items and monthly appointments) as a list of strings
    public List<String> getAllData() {
        List<String> allData = new ArrayList<>();

        // Adding inventory items to the list
        if (itemsIninv.isEmpty()) {
            allData.add("No inventory items available.");
        } else {
            for (inventory.InventoryItem item : itemsIninv) {
                allData.add(item.toString());
            }
        }

        // Adding monthly appointments to the list


        return allData;
    }
    public int getNumberOfPatents()
    {
        return this.apoiments.size();
    }
    public double getMonthlyR()
    {
        int numOfp = this.getNumberOfPatents();
        double r = this.PriceOfoneP * numOfp;
        return r;
    }

}

