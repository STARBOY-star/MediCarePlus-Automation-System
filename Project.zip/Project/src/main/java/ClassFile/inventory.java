package ClassFile;

import conn.conn;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class inventory {
    private static final conn con = new conn();
    private final Connection connection = con.GetDatabseConn();

    // Inner class representing an inventory item
    public static class InventoryItem {
        private int id;
        private String name;
        private String type;
        private double price;
        private int quantity;

        public InventoryItem(int id, String name, String type, double price, int quantity) {
            this.id = id;
            this.name = name;
            this.type = type;
            this.price = price;
            this.quantity = quantity;
        }

        // Getters and Setters
        public int getId() { return id; }
        public void setId(int id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getType() { return type; }
        public void setType(String type) { this.type = type; }
        public double getPrice() { return price; }
        public void setPrice(double price) { this.price = price; }
        public int getQuantity() { return quantity; }
        public void setQuantity(int quantity) { this.quantity = quantity; }

        @Override
        public String toString() {
            return id + ": " + name + " (" + type + ") - $" + price + " x " + quantity;
        }
    }

    // Add a new item to the database
    public void addItem(String name, String type, double price, int quantity) {
        String query = "INSERT INTO inventory (Name, Type, Price, Quantity) VALUES ( ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, type);
            preparedStatement.setDouble(3, price);
            preparedStatement.setInt(4, quantity);
            int x = preparedStatement.executeUpdate();
            if(x == 1)
            {
                JOptionPane.showMessageDialog(null, " added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Edit an existing item by ID
    public boolean editItem(int id, String name, String type, double price, int quantity) {
        String query = "UPDATE inventory SET Name = ?, Type = ?, Price = ?, Quantity = ? WHERE InventoryID = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, type);
            preparedStatement.setDouble(3, price);
            preparedStatement.setInt(4, quantity);
            preparedStatement.setInt(5, id);
            return preparedStatement.executeUpdate() > 0; // Returns true if the item was updated
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get all items from the database
    public List<InventoryItem> getItems() {
        List<InventoryItem> items = new ArrayList<>();
        String query = "SELECT * FROM inventory";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                int id = resultSet.getInt("InventoryID");
                String name = resultSet.getString("Name");
                String type = resultSet.getString("Type");
                double price = resultSet.getDouble("Price");
                int quantity = resultSet.getInt("Quantity");
                items.add(new InventoryItem(id, name, type, price, quantity));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }
    // Add method to generate a monthly report of inventory items
    public static List<InventoryItem> getMonthlyReport(int month, int year) {
        List<InventoryItem> items = new ArrayList<>();
        String query = "SELECT * FROM inventory WHERE MONTH(DateAdded) = ? AND YEAR(DateAdded) = ?";

        try (Connection connection = con.GetDatabseConn();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, month);
            preparedStatement.setInt(2, year);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    int id = resultSet.getInt("InventoryID");
                    String name = resultSet.getString("Name");
                    String type = resultSet.getString("Type");
                    double price = resultSet.getDouble("Price");
                    int quantity = resultSet.getInt("Quantity");
                    items.add(new InventoryItem(id, name, type, price, quantity));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return items;
    }

    // Remove an item by ID from the database
    public boolean removeItemById(int id) {
        String query = "DELETE FROM inventory WHERE InventoryID = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            int rowsAffected = preparedStatement.executeUpdate();

            // If rowsAffected is greater than 0, the item was successfully removed
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Item removal failed
    }

}
