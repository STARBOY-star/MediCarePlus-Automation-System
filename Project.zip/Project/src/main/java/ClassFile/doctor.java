package ClassFile;

import conn.conn;
import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class doctor {
    private conn con = new conn();
    private int doctorID;
    private String name;
    private String contact;
    private String special;

    // Constructor for retrieving doctors from the database
    public doctor(int doctorID, String name, String contact, String special) {
        this.doctorID = doctorID;
        this.name = name;
        this.contact = contact;
        this.special = special;
    }

    // Constructor for adding new doctors
    public doctor(String name, String contact, String special) {
        this.name = name;
        this.contact = contact;
        this.special = special;
    }
    public doctor(int doctorID) {
        this.doctorID = doctorID;
    }

    // Add Doctor to database
    public void addDoctorToDatabase() {
        try (Connection connection = con.GetDatabseConn()) {
            String query = "INSERT INTO doctor (Name, Contact, Special) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, contact);
                preparedStatement.setString(3, special);
                int rowsInserted = preparedStatement.executeUpdate();
                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(null, "Doctor added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error inserting data into the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error connecting to the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Get all doctors from the database
    public static List<doctor> getAllDoctors() {
        List<doctor> doctors = new ArrayList<>();
        conn con = new conn();
        try (Connection connection = con.GetDatabseConn()) {
            String query = "SELECT * FROM doctor";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    int doctorID = resultSet.getInt("DoctorID");
                    String name = resultSet.getString("Name");
                    String contact = resultSet.getString("Contact");
                    String special = resultSet.getString("Special");
                    doctor doctor = new doctor(doctorID, name, contact, special);
                    doctors.add(doctor);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching doctors from the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return doctors;
    }

    // Remove a doctor from the database
    public void removeDoctorFromDatabase(int doctorID) {
        try (Connection connection = con.GetDatabseConn()) {
            String query = "DELETE FROM doctor WHERE DoctorID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, doctorID);
                int rowsDeleted = preparedStatement.executeUpdate();
                if (rowsDeleted > 0) {
                    JOptionPane.showMessageDialog(null, "Doctor removed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error deleting doctor from the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error connecting to the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Getters and Setters
    public int getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(int doctorID) {
        this.doctorID = doctorID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getSpecial() {
        return special;
    }

    public void setSpecial(String special) {
        this.special = special;
    }
}
