package ClassFile;

import conn.conn;

import javax.swing.*;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class patient {
    public conn con = new conn();
    private int patientID;
    private String name;
    private String gender;
    private String contact;
    private String Email;

    public patient(int patientID, String name, String gender, String contact, String Email) {
        this.patientID = patientID;
        this.name = name;
        this.gender = gender;
        this.contact = contact;
        this.Email = Email;
    }

    public patient(String name, String gender, String contact, String Email) {
        this.name = name;
        this.gender = gender;
        this.contact = contact;
        this.Email = Email;
    }

    public patient() {}

    public void addPatientToDatabase() {
        String query = "INSERT INTO patient (Name, Gender, Contact, Email) VALUES (?, ?, ?, ?)";
        try (Connection connection = con.GetDatabseConn();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, gender);
            preparedStatement.setString(3, contact);
            preparedStatement.setString(4, Email);
            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Patient added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error inserting data into the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static List<patient> getAllPatients() {
        List<patient> patients = new ArrayList<>();
        String query = "SELECT * FROM patient";
        conn con = new conn();
        try (Connection connection = con.GetDatabseConn();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                int patientID = resultSet.getInt("PatientID");
                String name = resultSet.getString("Name");
                String gender = resultSet.getString("Gender");
                String contact = resultSet.getString("Contact");
                String email = resultSet.getString("Email");
                patients.add(new patient(patientID, name, gender, contact, email));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching patients from the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return patients;
    }

    public void removePatientFromDatabase(int patientID) {
        String query = "DELETE FROM patient WHERE PatientID = ?";
        try (Connection connection = con.GetDatabseConn();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, patientID);
            int rowsDeleted = preparedStatement.executeUpdate();
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(null, "Patient removed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error deleting data from the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static boolean CheckDate(String date) {
        // Placeholder for actual date validation logic
        // Return true if the date matches desired criteria
        return true; // For demonstration purposes
    }

    // Getters and setters
    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}
