package main;

import ClassFile.inventory;
import ClassFile.inventory.InventoryItem;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Inventory extends JFrame {
    private JPanel Inventory;
    private JList<String> list1;
    private JTextField Name;
    private JTextField Type;
    private JTextField Price;
    private JTextField Quantity;
    private JButton ADDButton;
    private JButton EDITButton;
    private JTextField id;
    private JTextField e_name;
    private JTextField e_tyepe;
    private JTextField e_price;
    private JTextField e_q;
    private JButton remove;

    public Inventory() {
        inventory inv = new inventory();
        setTitle("Inventory");
        setContentPane(Inventory);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setVisible(true);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Load initial inventory data into the JList
        loadInventoryList(inv);

        ADDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Validate fields
                    if (Name.getText().isEmpty() || Type.getText().isEmpty() ||
                            Price.getText().isEmpty() || Quantity.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "All fields are required!",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Parse price and quantity
                    double price = Double.parseDouble(Price.getText());
                    int quantity = Integer.parseInt(Quantity.getText());

                    // Check for valid input
                    if (price <= 0 || quantity <= 0) {
                        JOptionPane.showMessageDialog(null,
                                "Price and Quantity must be greater than zero!",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Add item to inventory
                    inv.addItem(Name.getText(), Type.getText(), price, quantity);
                    JOptionPane.showMessageDialog(null,
                            "Item added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                    // Refresh the inventory list
                    loadInventoryList(inv);

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null,
                            "Please enter valid numbers for Price and Quantity!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        EDITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Validate fields
                    if (id.getText().isEmpty() || e_name.getText().isEmpty() || e_tyepe.getText().isEmpty() ||
                            e_price.getText().isEmpty() || e_q.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "All fields are required for editing!",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Parse ID, price, and quantity
                    int itemId = Integer.parseInt(id.getText());
                    double price = Double.parseDouble(e_price.getText());
                    int quantity = Integer.parseInt(e_q.getText());

                    // Check for valid input
                    if (price <= 0 || quantity <= 0) {
                        JOptionPane.showMessageDialog(null,
                                "Price and Quantity must be greater than zero!",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Edit item in inventory
                    boolean success = inv.editItem(itemId, e_name.getText(), e_tyepe.getText(), price, quantity);
                    if (success) {
                        JOptionPane.showMessageDialog(null,
                                "Item updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                        // Refresh the inventory list
                        loadInventoryList(inv);
                    } else {
                        JOptionPane.showMessageDialog(null,
                                "Item with ID " + itemId + " not found!",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null,
                            "Please enter valid numbers for ID, Price, and Quantity!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        remove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int itemId = Integer.parseInt(id.getText());
                boolean x = inv.removeItemById(itemId);
                if (x) {
                    JOptionPane.showMessageDialog(null,
                            "Item Removed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                    // Refresh the inventory list
                    loadInventoryList(inv);
                } else {
                    JOptionPane.showMessageDialog(null,
                            "ERROR", "Success", JOptionPane.INFORMATION_MESSAGE);

                    // Refresh the inventory list
                }
            }
        });
    }

    // Method to load the inventory items into the JList
    private void loadInventoryList(inventory inv) {
        List<InventoryItem> items = inv.getItems();
        DefaultListModel<String> model = new DefaultListModel<>();
        for (InventoryItem item : items) {
            model.addElement(item.toString());
        }
        list1.setModel(model);
    }

    public static void main(String[] args) {
        new Inventory();
    }
}
