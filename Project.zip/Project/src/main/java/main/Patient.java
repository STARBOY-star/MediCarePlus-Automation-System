package main;

import ClassFile.patient;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Patient extends JFrame {
    private JPanel Patient;
    private JButton add;
    private JButton Appointment;
    private JTextField Name;
    private JTextField Gender;
    private JTextField Contact;
    private JTable table1;
    private JButton remove;
    private JTextField P_R_ID;
    private JTextField email;

    public Patient() {
        setTitle("Patient");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setContentPane(Patient);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
        setSize(1000, 600);
        this.loadPatientData();
        Appointment.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                main.Appointment a = new main.Appointment();
                a.setVisible(true);
                dispose();
            }
        });
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get data from text fields
                String name = Name.getText();
                String gender = Gender.getText();
                String contact = Contact.getText();
                String  Email  = email.getText();
                // Check if fields are empty
                if (name.isEmpty() || gender.isEmpty() || contact.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Create a new patient instance with the data
                    patient newPatient = new patient(name, gender, contact, Email);
                    newPatient.addPatientToDatabase(); // Add patient to the database

                    // Reload patient data after inserting the new patient
                    loadPatientData();
                }
            }
        });
        remove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get Patient ID from text field
                String patientIDText = P_R_ID.getText();

                // Check if the ID field is empty
                if (patientIDText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter a Patient ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    int patientID = Integer.parseInt(patientIDText);

                    // Create a patient instance and call remove method
                    patient p = new patient(null,null,null,null); // Create a patient object
                    p.removePatientFromDatabase(patientID); // Call method to remove patient from database

                    // Reload patient data after removing the patient
                    loadPatientData();

                    // Clear the ID field after operation
                    P_R_ID.setText("");

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid Patient ID. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
    private void loadPatientData() {
        // Define table model
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Patient ID");
        model.addColumn("Name");
        model.addColumn("Gender");
        model.addColumn("Contact");

        // Fetch patient data from the database

        List<patient> patients = patient.getAllPatients();

        // Add each patient to the table
        for (patient p : patients) {
            model.addRow(new Object[]{
                    p.getPatientID(),
                    p.getName(),
                    p.getGender(),
                    p.getContact()
            });
        }

        // Set the model to the table
        table1.setModel(model);
    }
    public static void main(String[] args) {
        Patient p =  new Patient();
        p.loadPatientData();
    }
}
