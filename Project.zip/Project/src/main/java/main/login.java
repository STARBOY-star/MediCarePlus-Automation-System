package main;
import main.Patient;

import javax.mail.MessagingException;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.security.GeneralSecurityException;

import ClassFile.appointment;

public class login extends JFrame {
    private JPanel login;
    private JRadioButton user;
    private JRadioButton pharmacist;
    private JRadioButton doctor;
    private JRadioButton admin;
    private appointment a = new appointment();



    public login() throws MessagingException, GeneralSecurityException, IOException {
       setTitle("Login");
       setSize(600, 500);
       setContentPane(login);
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       setLocationRelativeTo(null);
       setVisible(true);

            a.informPatient();

        // Explicitly set action commands
        user.setActionCommand("user");
        pharmacist.setActionCommand("pharmacist");
        doctor.setActionCommand("doctor");
        admin.setActionCommand("admin");
        ActionListener listener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (e.getActionCommand()) {
                    case "user":
                        System.out.println(e.getActionCommand());
                        try {
                            makeOtherbtnUnbtn(1);
                        } catch (MessagingException ex) {
                            throw new RuntimeException(ex);
                        } catch (GeneralSecurityException ex) {
                            throw new RuntimeException(ex);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        break;
                    case "pharmacist":
                        try {
                            makeOtherbtnUnbtn(2);
                        } catch (MessagingException ex) {
                            throw new RuntimeException(ex);
                        } catch (GeneralSecurityException ex) {
                            throw new RuntimeException(ex);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        break;
                    case "doctor":
                        try {
                            makeOtherbtnUnbtn(3);
                        } catch (MessagingException ex) {
                            throw new RuntimeException(ex);
                        } catch (GeneralSecurityException ex) {
                            throw new RuntimeException(ex);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        break;
                    case "admin":
                        try {
                            makeOtherbtnUnbtn(4);
                        } catch (MessagingException ex) {
                            throw new RuntimeException(ex);
                        } catch (GeneralSecurityException ex) {
                            throw new RuntimeException(ex);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        break;
                    default:
                        try {
                            makeOtherbtnUnbtn(5);
                        } catch (MessagingException ex) {
                            throw new RuntimeException(ex);
                        } catch (GeneralSecurityException ex) {
                            throw new RuntimeException(ex);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        break;
                }
            }
        };
        user.addActionListener(listener);
        admin.addActionListener(listener);
        doctor.addActionListener(listener);
        pharmacist.addActionListener(listener);
    }


    public void makeOtherbtnUnbtn(int id) throws MessagingException, GeneralSecurityException, IOException {
        switch (id) {
            case 1 -> {
                main.Patient p = new Patient();
                p.setVisible(true);
                pharmacist.setSelected(false);
                doctor.setSelected(false);
                admin.setSelected(false);
            }
            case 2 -> {
                main.Pharmacists p = new Pharmacists();
                p.setVisible(true);
                user.setSelected(false);
                doctor.setSelected(false);
                admin.setSelected(false);

            }
            case 3 -> {
                main.Doctor p = new Doctor();
                p.setVisible(true);
                user.setSelected(false);
                pharmacist.setSelected(false);
                admin.setSelected(false);

            }
            case 4 -> {
                main.admin p = new admin();
                p.setVisible(true);
                user.setSelected(false);
                pharmacist.setSelected(false);
                doctor.setSelected(false);

            }
            default -> {


                pharmacist.setSelected(false);
                admin.setSelected(false);
                doctor.setSelected(false);

            }
        }
        // Refresh UI
        login.revalidate();
        login.repaint();
    }


    public static void main(String[] args) throws MessagingException, GeneralSecurityException, IOException {
        new login();
    }
}
