package main;

import ClassFile.doctor;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.stream.Collectors;

public class Doctor extends JFrame {
    private JPanel Doctor;
    private JList<String> list1;
    private JTextField Name;
    private JTextField Contact;
    private JTextField Special;
    private JButton submit;
    private JButton Remove;

    private DefaultListModel<String> listModel;

    public Doctor() {
        setTitle("Doctor");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setContentPane(Doctor);
        setLocationRelativeTo(null);
        setResizable(false);
        setSize(600, 509);

        listModel = new DefaultListModel<>();
        list1.setModel(listModel);

        refreshDoctorList();

        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addDoctor();
            }
        });

        Remove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeDoctor();
            }
        });

        setVisible(true);
    }

    private void addDoctor() {
        String name = Name.getText().trim();
        String contact = Contact.getText().trim();
        String special = Special.getText().trim();

        if (name.isEmpty() || contact.isEmpty() || special.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        doctor newDoctor = new doctor(name, contact, special);
        newDoctor.addDoctorToDatabase();
        refreshDoctorList();
        clearFields();
    }

    private void removeDoctor() {
        int selectedIndex = list1.getSelectedIndex();
        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(null, "Please select a doctor to remove!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String selectedValue = list1.getSelectedValue();
        int doctorID = Integer.parseInt(selectedValue.split(" - ")[0]); // Extract DoctorID

        doctor doctorToRemove = new doctor(doctorID); // Temporary instance to call the method
        doctorToRemove.removeDoctorFromDatabase(doctorID);
        refreshDoctorList();
    }

    private void refreshDoctorList() {
        listModel.clear();
        List<doctor> doctors = doctor.getAllDoctors();
        for (doctor doc : doctors) {
            listModel.addElement(doc.getDoctorID() + " - " + doc.getName() + " (" + doc.getSpecial() + ")");
        }
    }

    private void clearFields() {
        Name.setText("");
        Contact.setText("");
        Special.setText("");
    }

    public static void main(String[] args) {
        new Doctor();
    }
}
