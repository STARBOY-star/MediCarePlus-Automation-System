package main;

import ClassFile.Admin; // Assuming you are using your 'admin' class from ClassFile package
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class admin extends JFrame {
    private JPanel admin;
    private JButton Patient_admin;
    private JButton Inventory_admin;
    private JButton Doctor_admin;
    private JButton Appointment_admin;
    private JButton R;
    private JTable table1;
    private JLabel Revenue;
    private JLabel PatientVisits;
    public Admin ax = new Admin();

    public admin() {
        setContentPane(admin);
        setTitle("ADMIN");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
        setSize(500, 509);


        // Initialize table with an empty model
        DefaultTableModel tableModel = new DefaultTableModel();
        table1.setModel(tableModel);

        // Define column names for your table (adjust as necessary)
        tableModel.addColumn("Data");

        // Set up action listeners
        Patient_admin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Patient p = new Patient();
                p.setVisible(true);
            }
        });

        Doctor_admin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Doctor p = new Doctor();
                p.setVisible(true);
            }
        });

        Inventory_admin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Inventory p = new Inventory();
                p.setVisible(true);
            }
        });

        Appointment_admin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Appointment p = new Appointment();
                p.setVisible(true);
            }
        });

        // Action listener for the "R" button
        R.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create an instance of the admin class and retrieve all data
                admin a = new admin();
                List<String> allData = a.ax.getAllData();

                // Clear any existing rows in the table model
                tableModel.setRowCount(0);

                // Add all data rows to the table model
                for (String data : allData) {
                    tableModel.addRow(new Object[]{data});
                }

                PatientVisits.setText(String.valueOf(ax.getNumberOfPatents()));
                Revenue.setText(String.valueOf(ax.getMonthlyR()));


            }
        });
    }

    public static void main(String[] args) {
        new admin();
    }
}
