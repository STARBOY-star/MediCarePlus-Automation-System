package main;

import ClassFile.doctor;
import ClassFile.patient;
import ClassFile.appointment;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.List;

public class Appointment extends JFrame {
    private JPanel Appointment;
    private JList<String> doc;
    private JList<String> Appointment_P;
    private JButton addAppointment;
    private JButton printSelectedButton;
    private JTable table1;
    private JButton R_BTN;

    private DefaultListModel<String> docModel;
    private DefaultListModel<String> appointmentModel;
    private DefaultTableModel tableModel;

    private List<doctor> doctorList;
    private List<patient> patientList;
    public appointment a = new appointment();
    public Appointment() {
        // Define column names
        String[] columnNames = {"ID", "Doctor Name", "Patient Name", "Date"};

        // Initialize the table model with column names
        tableModel = new DefaultTableModel(columnNames, 0);
        table1.setModel(tableModel);

        setTitle("Appointment");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setContentPane(Appointment);
        setLocationRelativeTo(null);
        setResizable(false);
        setSize(1000, 500);

        // Initialize the models
        docModel = new DefaultListModel<>();
        appointmentModel = new DefaultListModel<>();

        // Fetch doctor and patient data from the database
        doctorList = doctor.getAllDoctors();
        populateDoctorList();

        patientList = patient.getAllPatients();
        populatePatientList();

        // Load existing appointments into the table
        loadAppointmentData();

        // Set the models to the JLists
        doc.setModel(docModel);
        Appointment_P.setModel(appointmentModel);

        setVisible(true);

        // Add Appointment Action
        addAppointment.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedDoctor = doc.getSelectedValue();
                String selectedPatient = Appointment_P.getSelectedValue();
                int Did = 0;
                int Pid = 0;
                for (doctor doctor : doctorList) {
                    if(selectedDoctor == doctor.getName())
                    {
                         Did = doctor.getDoctorID();
                    }
                }

                for (patient patient : patientList) {
                    if(selectedPatient == patient.getName())
                    {
                         Pid = patient.getPatientID();
                    }
                }
                System.out.println(Did + ", " + Pid);
                if (selectedDoctor != null && selectedPatient != null) {


                    a.addAppointmentToDatabase(Did,Pid);


                    JOptionPane.showMessageDialog(null, "Appointment added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select both doctor and patient and provide a date.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Remove Appointment Action
        R_BTN.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table1.getSelectedRow();

                // Check if a row is selected
                if (selectedRow != -1) {
                    // Retrieve the AppointmentID from the selected row
                    int appointmentID = (int) table1.getValueAt(selectedRow, 0);  // Assuming the AppointmentID is in the first column (index 0)

                    // Call the removeAppointment method and pass the AppointmentID
                    boolean success = a.removeAppointment(appointmentID);

                    // If appointment removal is successful, remove from the table model
                    if (success) {
                        tableModel.removeRow(selectedRow);
                        JOptionPane.showMessageDialog(null, "Appointment removed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error removing appointment.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select an appointment to remove.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

    }

    private void loadAppointmentData() {
        // Fetch appointment data from the database
        List<appointment> appointments = appointment.getAllAppointments();

        for (appointment a : appointments) {
            tableModel.addRow(new Object[]{
                    a.getAppointmentID(),
                    a.getDoctorName(),
                    a.getPatientName(),
                    a.getDate()
            });
        }
    }

    private void populateDoctorList() {
        for (doctor doctor : doctorList) {
            docModel.addElement(doctor.getName());
        }
    }

    private void populatePatientList() {
        for (patient patient : patientList) {
            appointmentModel.addElement(patient.getName());
        }
    }

    private void addDataToTable(int id, String doctorName, String patientName, String appointmentDate) {
        tableModel.addRow(new Object[]{id, doctorName, patientName, appointmentDate});
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Appointment());
    }
}
