package main;

import ClassFile.Pharmacist;

import javax.mail.MessagingException;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.security.GeneralSecurityException;

public class Pharmacists extends JFrame {
    private JPanel Pharmacists;
    private JTextField email;
    private JTextField loginEmail;
    private JTextField tel;
    private JTextField name;
    private JButton LOGINButton;
    private JButton REGSITER;

    public Pharmacists() throws MessagingException, GeneralSecurityException, IOException {
        setTitle("Pharmacists");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setContentPane(Pharmacists);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
        setSize(800, 300);
        Pharmacist ph2 = new Pharmacist();
        ph2.informPharmacist();
        // Register Button Action
        REGSITER.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String pharmacistName = name.getText().trim();
                String pharmacistTel = tel.getText().trim();
                String pharmacistEmail = email.getText().trim();

                if (pharmacistName.isEmpty() || pharmacistTel.isEmpty() || pharmacistEmail.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Create Pharmacist instance and register
                Pharmacist pharmacist = new Pharmacist(pharmacistName, pharmacistTel, pharmacistEmail);
                pharmacist.addPharmacistToDatabase();
            }
        });

        // Login Button Action
        LOGINButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String loginEmailText = loginEmail.getText().trim();

                if (loginEmailText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Email field is required for login!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Check if email exists in the database
                Pharmacist tempPharmacist = new Pharmacist("", "", loginEmailText);
                if (tempPharmacist.isEmailInDatabase(loginEmailText)) {
                   main.Inventory i = new Inventory();
                   i.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Email not found in the database!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) throws MessagingException, GeneralSecurityException, IOException {
        new Pharmacists();
    }
}
